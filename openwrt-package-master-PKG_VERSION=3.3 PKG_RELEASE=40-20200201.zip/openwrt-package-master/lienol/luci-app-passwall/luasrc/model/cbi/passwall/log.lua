m = Map("passwall")
m:append(Template("passwall/log/log"))
return m
